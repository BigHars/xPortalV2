﻿using xPortal.MockData;

namespace xPortal.model
{
    public class Movie
    {
        #region properties
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int Rating { get; set; }
        public DateTime ReleaseDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public List<DateTime> Time { get; set; }
        public bool HasExpired { get; set; }
        public string Picture { get; set; }
        public TimeSpan RunningTime { get; set; }
        public string BannerImg { get; set; }
        public string LeadActor { get; set; }
        public string Director { get; set; }
        public string MusicBy { get; set; }
        public string Genre { get; set; }
        #endregion

        #region constructors
        public Movie()
        {
        }

        public Movie(int id, string title, string description, int rating, DateTime releaseDate,
            DateTime expirationDate, List<DateTime> time, bool hasExpired, string picture, TimeSpan runningTime, string bannerImg, string leadActor, string director, string musicBy, string genre)
        {
            Id = id;
            Title = title;
            Description = description;
            Rating = rating;
            ReleaseDate = releaseDate;
            ExpirationDate = expirationDate;
            Time = time;
            HasExpired = hasExpired;
            Picture = picture;
            RunningTime = runningTime;
            BannerImg = bannerImg;
            LeadActor = leadActor;
            Director = director;
            MusicBy = musicBy;
            Genre = genre;
        }
        #endregion

        #region methods
        public void CheckIfExpired()
        {
            if (ExpirationDate > DateTime.Now)
            {
                HasExpired = true;
            } else
            {
                HasExpired = false;
            }
        }

        public static Movie FindMovie(int id)
        {
            foreach (Movie m in MovieMock.movieList)
            {
                if (m.Id == id)
                {
                    return m;
                }
            }
            throw new KeyNotFoundException($"{id} findes ikke i databasen");
        }

        public override string ToString()
        {
            return Id + " " + Title + " " + Description + " " + Rating + " " + 
                ReleaseDate + " " + ExpirationDate + " " + Time;
        }
        #endregion
    }
}
