﻿using xPortal.MockData;
using xPortal.model;

namespace xPortal.model
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Movie FavMovie { get; set; }

        public User()
        {}
        public User(int id, string name, Movie favMovie)
        {
            Id = id;
            Name = name;
            FavMovie = favMovie;
        }

        public override string ToString()
        {
            return $"{nameof(Id)}={Id.ToString()}, {nameof(Name)}={Name}, {nameof(FavMovie)}={FavMovie}";
        }
    }
}
