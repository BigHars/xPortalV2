﻿using xPortal.MockData;

namespace xPortal.model
{
    public class Biografer
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public int Postnummer { get; set; }
        public Faciliteter Faciliteter { get; set; }
        public List<Movie> MoviesShowing { get; set; }

        public Biografer(int id, string name, int postnummer, Faciliteter faciliteter)
        {
            Id = id;
            Name = name;
            Postnummer = postnummer;
            Faciliteter = faciliteter;
            MoviesShowing = new List<Movie>(); //Connection mellem movie og kino
        }

        public override string ToString()
        {
            return $"{{{nameof(Id)}={Id.ToString()}, {nameof(Name)}={Name}, {nameof(Postnummer)}={Postnummer.ToString()}, {nameof(Faciliteter)}={Faciliteter}}}";
        }
    }
}
