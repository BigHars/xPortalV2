﻿namespace xPortal.model
{
    public class Faciliteter
    {
        public bool Luxseats { get; set; }
        public bool Nokids { get; set; }
        public bool Curvedscreen { get; set; }
        public bool Handicapaccess { get; set; }
        public bool Smokingallowed { get; set; }

        public Faciliteter(bool luxseats, bool nokids, bool curvedscreen, bool handicapaccess, bool smokingallowed)
        {
            Luxseats = luxseats;
            Nokids = nokids;
            Curvedscreen = curvedscreen;
            Handicapaccess = handicapaccess;
            Smokingallowed = smokingallowed;
        }

        public override string ToString()
        {
            return $"{{{nameof(Luxseats)}={Luxseats.ToString()}, {nameof(Nokids)}={Nokids.ToString()}, {nameof(Curvedscreen)}={Curvedscreen.ToString()}, {nameof(Handicapaccess)}={Handicapaccess.ToString()}, {nameof(Smokingallowed)}={Smokingallowed.ToString()}}}";
        }

        private String ConvertBool(bool value)
        {
            return value ? "Ja" : "Nej";
        }
    }
}
