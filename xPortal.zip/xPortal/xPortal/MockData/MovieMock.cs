﻿using System;
using xPortal.model;

namespace xPortal.MockData
{
    public class MovieMock
    {
        #region saw DateTime
        private static List<DateTime> sawDates = new List<DateTime>()
        {
            new DateTime(1, 1, 1, 14, 30, 0),
            new DateTime(1, 1, 1, 16, 30, 0),
            new DateTime(1, 1, 1, 18, 45, 0),
            new DateTime(1, 1, 1, 23, 0, 0)
        };
        #endregion

        #region wonkaDates DateTime
        private static List<DateTime> wonkaDates = new List<DateTime>()
        {
            new DateTime(1, 1, 1, 12, 30, 0),
            new DateTime(1, 1, 1, 14, 0, 0),
            new DateTime(1, 1, 1, 17, 30, 0),
            new DateTime(1, 1, 1, 20, 0, 0)
        };
        #endregion

        #region granTurismoDates DateTime
        private static List<DateTime> granTurismoDates = new List<DateTime>()
        {
            new DateTime(1, 1, 1, 12, 30, 0),
            new DateTime(1, 1, 1, 14, 0, 0),
            new DateTime(1, 1, 1, 17, 30, 0),
            new DateTime(1, 1, 1, 20, 0, 0)
        };
        #endregion

        #region fiveNightsDates DateTime
        private static List<DateTime> fiveNightsDates = new List<DateTime>()
        {
            new DateTime(1, 1, 1, 15, 30, 0),
            new DateTime(1, 1, 1, 17, 0, 0),
            new DateTime(1, 1, 1, 21, 30, 0),
            new DateTime(1, 1, 1, 23, 0, 0)
        };
        #endregion


        public static List<Movie> movieList = new List<Movie>()
        {
            new Movie(1, "Saw X", "Chasing a promising procedure that would allegedly cure his cancer, John Kramer heads towards Mexico to go through an experimental treatment, only to find out he was prey for a scam. Now, the scammers becomes the prey on Jigsaw's new game.", 5, new DateTime(2023, 9, 29, 14, 30, 0), new DateTime(2024, 1, 5, 14, 30, 0), sawDates, false, "https://i0.wp.com/bloody-disgusting.com/wp-content/uploads/2023/07/saw-x-poster.jpg?resize=740%2C925&ssl=1", new TimeSpan(1, 58, 0), "https://static1.cbrimages.com/wordpress/wp-content/uploads/2021/05/John-Kramer-Jigsaw-Header.jpg", "Tobin Bell", "Kevin Greutert", "Charlie Clouser", "Horror, Crime"),
            new Movie(2, "Wonka", "The story will focus specifically on a young Willy Wonka and how he met the Oompa-Loompas on one of his earliest adventures.", 4, new DateTime(2023, 12, 15, 23, 30, 0), new DateTime(2024, 3, 16, 12, 30, 0), wonkaDates, false, "https://m.media-amazon.com/images/M/MV5BNzJiZGRkMDgtZWFlOS00MWRhLThhNTEtMjljZTJjYTljYTBjXkEyXkFqcGdeQXVyMTEyMjM2NDc2._V1_FMjpg_UX1000_.jpg", new TimeSpan(2, 30, 0), "https://www.highonfilms.com/wp-content/uploads/2023/07/Timothee-Chalamet-in-as-Wonka-2023-Trailer-scaled.webp", "Tomothee Chalamet", "Paul King", "Anthony Newley", "Fantasy, Comedy"),
            new Movie(3, "Gran Turismo", "Based on the unbelievable, inspiring true story of a team of underdogs - a struggling, working-class gamer, a failed former race car driver, and an idealistic motorsport exec - who risk it all to take on the most elite sport in the world.", 5, new DateTime(2023, 8, 16, 15, 30, 0), new DateTime(2024, 1, 13, 12, 30, 0), granTurismoDates, false, "https://m.media-amazon.com/images/M/MV5BMTI1YjFmN2UtOWZhOC00MjkwLTg2ZjgtNDQ5NDQ3YWNmNGRkXkEyXkFqcGdeQXVyMTAxNzQ1NzI@._V1_.jpg", new TimeSpan(2, 14, 0), "https://www.videogameschronicle.com/files/2023/08/gt-crash.jpg", "Archie Madekwe", "Neill Blomkamp", "Lorne Balfe", "Action"),
            new Movie (4, "Five Nights at Freddy's", "A troubled security guard begins working at Freddy Fazbear's Pizza. During his first night on the job, he realizes that the night shift won't be so easy to get through. Pretty soon he will unveil what actually happened at Freddy's.", 3, new DateTime(2023, 10, 23, 23, 30, 0), new DateTime(2024, 2, 14, 18, 30, 0), fiveNightsDates, false, "https://movies.universalpictures.com/media/fnf-tsr1sheet-foxy1-dateonly-rgb-2-1-646527e7ae6df-1.jpg", new TimeSpan(2, 14, 0), "https://i2-prod.walesonline.co.uk/incoming/article27215412.ece/ALTERNATES/s1200/0_Blumhouses-Next-Five-Nights-at-Freddys-Trailer-Is-Coming-Soon-Runtime-Revealed-Image-3.jpg", "Josh Hutcherson", "Emma Tammi", "Tyler Bates", "Horror, Thriller")

        };

        public static List<Movie> GetMovie()
        {
            return new List<Movie>(movieList);
        }

    }
}
