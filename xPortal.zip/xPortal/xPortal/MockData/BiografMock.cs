﻿using xPortal.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.WebSockets;

namespace xPortal.MockData
{
    public static class BiografMock
    {

        private const bool LuxseatsYES = true;
        private const bool LuxseatsNO = false;

        private const bool NokidsTRUE = true;
        private const bool NokidsFALSE = false;

        private const bool CurvedscreenYES = true;
        private const bool CurvedscreenNO = false;

        private const bool HandicapYES = true;
        private const bool HandicapNO = false;

        private const bool SmokingYES = true;
        private const bool SmokingNO = false;

        private static readonly List<Biografer> biograferList = new List<Biografer>()
        {
            new Biografer (1, "Kino Ro's torv", 4000, new Faciliteter(LuxseatsNO,NokidsFALSE,CurvedscreenNO,HandicapNO,SmokingYES)),
            new Biografer (2, "CinemaXx Fisketorvet", 1560, new Faciliteter(LuxseatsYES,NokidsTRUE,CurvedscreenYES,HandicapYES,SmokingNO)),
            new Biografer (3, "Biffen i Holstebro", 7500, new Faciliteter(LuxseatsNO,NokidsFALSE,CurvedscreenNO,HandicapYES,SmokingYES)),
            new Biografer (4, "Vue Odense", 5000, new Faciliteter(LuxseatsYES,NokidsTRUE,CurvedscreenYES,HandicapNO,SmokingNO))
        };

        public static List<Biografer> GetBiografer()
        {
            var kino1 = new Biografer(1, "Kino Ro's torv", 4000, new Faciliteter(LuxseatsNO, NokidsFALSE, CurvedscreenNO, HandicapNO, SmokingYES));
            var kino2 = new Biografer(2, "CinemaXx Fisketorvet", 1560, new Faciliteter(LuxseatsYES, NokidsTRUE, CurvedscreenYES, HandicapYES, SmokingNO));
            var kino3 = new Biografer(3, "Biffen i Holstebro", 7500, new Faciliteter(LuxseatsNO, NokidsFALSE, CurvedscreenNO, HandicapYES, SmokingYES));
            var kino4 = new Biografer(4, "Vue Odense", 5000, new Faciliteter(LuxseatsYES, NokidsTRUE, CurvedscreenYES, HandicapNO, SmokingNO));

            kino1.MoviesShowing.AddRange(new List<Movie> { MovieMock.movieList[0], MovieMock.movieList[1] });
            kino2.MoviesShowing.AddRange(new List<Movie> { MovieMock.movieList[2], MovieMock.movieList[3] });
            kino3.MoviesShowing.AddRange(new List<Movie> { MovieMock.movieList[0], MovieMock.movieList[1], MovieMock.movieList[2] });
            kino4.MoviesShowing.AddRange(new List<Movie> { MovieMock.movieList[0], MovieMock.movieList[1], MovieMock.movieList[2], MovieMock.movieList[3] });

            var biografer = new List<Biografer> { kino1, kino2, kino3, kino4 };
            return biografer;
        }
    }
}
