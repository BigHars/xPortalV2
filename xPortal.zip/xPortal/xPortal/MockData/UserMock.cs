﻿using xPortal.model;

namespace xPortal.MockData
{
    public class UserMock
    {
        public static readonly List<User> userList = new List<User>()
        {
            new User(1, "Magnus", Movie.FindMovie(1)),
            new User(2, "Hasse", Movie.FindMovie(2)),
            new User(3, "Theis", Movie.FindMovie(3)),
            new User(4, "Lasse", Movie.FindMovie(4))
        };

        public static List<User> GetUsers()
        {
            return new List<User>(userList);
        }
    }
}
