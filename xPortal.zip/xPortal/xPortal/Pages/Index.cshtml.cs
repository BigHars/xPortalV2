﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using xPortal.MockData;
using xPortal.model;

namespace xPortal.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        [BindProperty]
        public List<Movie> Movies { get; set; }



        public void OnGet()
        {
            Movies = MovieMock.GetMovie();
        }

        public IActionResult OnPostSelectedMovie(int id)
        {
            return RedirectToPage("MovieDetails", new { Id = id});
        }

    }
}