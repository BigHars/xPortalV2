using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using xPortal.model;

namespace xPortal.Pages.Shared
{
    public class MovieDetailsModel : PageModel
    {
        [BindProperty]
        public Movie SelectedMovie { get; set; }
        public void OnGet(int id)
        {
            SelectedMovie = Movie.FindMovie(id);
        }
    }
}
